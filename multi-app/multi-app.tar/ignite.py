from openfabric_pysdk.starter import Starter

if __name__ == '__main__':
    Starter.ignite(debug=False, host="0.0.0.0", port=5000),
