#!/bin/bash
start_code_server
python ./ignite.py

while true
do
	sleep 1
done
# python ./ignite.py