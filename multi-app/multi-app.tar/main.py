from typing import Dict, List, Union
import requests
import proxy as prx
import utils
from openfabric_pysdk.context import MessageType, Ray, State, StateStatus
from openfabric_pysdk.helper import Proxy
from openfabric_pysdk.loader import ConfigClass, InputClass, OutputClass
from openfabric_pysdk.utility import SchemaUtil
from openfabric_pysdk.service.property_service import PropertyService
import spacy

nlp = spacy.load(".")

user_configs = dict()
# TODO: add proxy links
# Retrieve proxy links from PropertyService
LLM_PROXY_LINK = PropertyService.get("multi_llm_proxy")
CWI_PROXY_LINK = PropertyService.get("multi_cwi_proxy")
STT_PROXY_LINK = PropertyService.get("multi_stt_proxy")

# Initialize Proxy objects
llm_proxy = Proxy(LLM_PROXY_LINK, "LLM proxy")
cwi_proxy = Proxy(CWI_PROXY_LINK, "CWI proxy")
stt_proxy = Proxy(STT_PROXY_LINK, "STT proxy")


def extract_crypto_from_query(query):
    doc = nlp(query)
    for ent in doc.ents:
        if ent.label_ == "CRYPTO":
            return ent.text.lower()
    return None

def get_crypto_symbol(slug):
    url = "https://pro-api.coinmarketcap.com/v2/cryptocurrency/info"
    params = {"slug": slug}
    headers = {"X-CMC_PRO_API_KEY": "1491e542-5af4-49b6-93bb-77df1a196765"}

    try:
        response = requests.get(url, headers=headers, params=params)
        data = response.json()

        if "data" in data:
            crypto_data = data["data"]
            for _, value in crypto_data.items():
                if value["slug"] == slug:
                    return value["symbol"]
            return "Cryptocurrency not found"
        else:
            return "No data found"
    except Exception as e:
        return f"Error occurred: {e}"
    
    
def get_latest_crypto_data(crypto_symbol):
    crypto_symbol = crypto_symbol.upper()
    url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest"
    params = {
        "start": "1",
        "limit": "100",
        "convert": "USD"
    }
    headers = {
        "X-CMC_PRO_API_KEY": "1491e542-5af4-49b6-93bb-77df1a196765"
    }
    
    response = requests.get(url, headers=headers, params=params)
    data = response.json()

    if 'data' in data:
        for crypto in data['data']:
            if crypto['symbol'] == crypto_symbol:
                market_data = {
                    "Name": crypto['name'],
                    "Symbol": crypto['symbol'],
                    "Price (USD)": crypto['quote']['USD']['price'],
                    "Volume 24h (USD)": crypto['quote']['USD']['volume_24h'],
                    "Market Cap (USD)": crypto['quote']['USD']['market_cap'],
                    "Max Supply": crypto['max_supply'],
                    "Circulating Supply": crypto['circulating_supply'],
                    "Total Supply": crypto['total_supply'],
                }
                return market_data
        return "Cryptocurrency not found"
    else:
        return "No data found"
    
# def execute(request: InputClass, ray: Ray,  state: State) -> OutputClass:
#     global user_configs

#     text_input = request.text
#     voice_input = request.voice
#     option = request.option
#     attachment = request.attachment
#     uid = ray.uid

#     # TODO: based on the option process the data further
#     ray.message(
#         MessageType.INFO,
#         content="Processing inputs..."
#     )

#     user_input: str = ""

#     if option == "textInput":
#         user_input = text_input
#     elif option == "voiceInput":
#         ray.message(
#             MessageType.INFO,
#             content="Converting voice to text..."
#         )
#         stt_output = prx.perform_stt_request(
#             stt_proxy, voice_input, uid
#         )
#         user_input = stt_output
    
#     user_input = user_input.strip() if user_input else None

#     # Check only attachment provided
#     if attachment is not None:
#         if user_input is None or user_input == "":
#             ray.message(
#                 MessageType.INFO,
#                 content="Only attachment found. Understanding the image..."
#             )
#             user_input = "What's this? Answer in detail."
#         else:
#             ray.message(
#                 MessageType.INFO,
#                 content="Understanding the image..."
#             )

#     # Check input empty
#     if (user_input is None or user_input == "") and attachment is None:
#         ray.message(
#             MessageType.ERROR,
#             content="No input text/voice/attachment found."
#         )
#         return SchemaUtil.create(
#             OutputClass(),
#             dict(
#                 response="No input text/voice/attachment found.",
#                 attachment=None
#             )
#         )
#     # Check token limit not exceeded
#     if user_input and utils.is_tokens_exceeded(user_input):
#         ray.message(
#             MessageType.ERROR,
#             content="Input text/voice is too long to be processed. Try again."
#         )
#         return SchemaUtil.create(
#             OutputClass(),
#             dict(
#                 response="Input text/voice is too long to be processed. Try again.",
#                 attachment=None
#             )
#         )

#     response: str = ""
#     respimg = None
    
#     if attachment is not None:
#         response, respimg = prx.perform_cwi_request(
#             cwi_proxy,
#             user_input, 
#             attachment, 
#             uid
#         )
#     else:
#         response = prx.perform_llm_request(
#             llm_proxy,
#             user_input,
#             uid
#         )

#     ray.message(
#         MessageType.INFO,
#         content="🎉 Generated response."
#     )

#     if response and response != "":
#         response = response[0].upper() + response[1: ]
#     else:
#         response = "No response was generated. Check the logs for any errors."

#     return SchemaUtil.create(
#         OutputClass(),
#         dict(
#             response=response,
#             attachment=respimg
#         )
#     )
def execute(request: InputClass, ray: Ray, state: State) -> OutputClass:
    global user_configs

    text_input = request.text
    voice_input = request.voice
    option = request.option
    attachment = request.attachment
    uid = ray.uid

    # TODO: based on the option process the data further
    ray.message(
        MessageType.INFO,
        content="Processing inputs..."
    )

    user_input: str = ""

    if option == "textInput":
        user_input = text_input
    elif option == "voiceInput":
        ray.message(
            MessageType.INFO,
            content="Converting voice to text..."
        )
        stt_output = prx.perform_stt_request(
            stt_proxy, voice_input, uid
        )
        user_input = stt_output

    user_input = user_input.strip() if user_input else None

    # Extract cryptocurrency from user query
    crypto = extract_crypto_from_query(user_input)

    if crypto:
        # Get symbol of the cryptocurrency
        symbol = get_crypto_symbol(crypto)
        if symbol != "Cryptocurrency not found":
            # Get latest data of the cryptocurrency
            data = get_latest_crypto_data(symbol)
            if data != "Cryptocurrency not found":
                # Combine cryptocurrency data with user query
                user_input += data
            else:
                user_input = text_input  # Send original query to LLM if crypto data not found.

    # Check only attachment provided
    if attachment is not None:
        if user_input is None or user_input == "":
            ray.message(
                MessageType.INFO,
                content="Only attachment found. Understanding the image..."
            )
            user_input = "What's this? Answer in detail."
        else:
            ray.message(
                MessageType.INFO,
                content="Understanding the image..."
            )

    # Check input empty
    if (user_input is None or user_input == "") and attachment is None:
        ray.message(
            MessageType.ERROR,
            content="No input text/voice/attachment found."
        )
        return SchemaUtil.create(
            OutputClass(),
            dict(
                response="No input text/voice/attachment found.",
                attachment=None
            )
        )
    # Check token limit not exceeded
    if user_input and utils.is_tokens_exceeded(user_input):
        ray.message(
            MessageType.ERROR,
            content="Input text/voice is too long to be processed. Try again."
        )
        return SchemaUtil.create(
            OutputClass(),
            dict(
                response="Input text/voice is too long to be processed. Try again.",
                attachment=None
            )
        )

    response: str = ""
    respimg = None

    if attachment is not None:
        response, respimg = prx.perform_cwi_request(
            cwi_proxy,
            user_input,
            attachment,
            uid
        )
    else:
        response = prx.perform_llm_request(
            llm_proxy,
            user_input,
            uid
        )

    ray.message(
        MessageType.INFO,
        content="🎉 Generated response."
    )

    if response and response != "":
        response = response[0].upper() + response[1:] 
    else:
        response = "No response was generated. Check the logs for any errors."

    return SchemaUtil.create(
        OutputClass(),
        dict(
            response=response,
            attachment=respimg
        )
    )
